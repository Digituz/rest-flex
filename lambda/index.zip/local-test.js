const MongoClient = require('mongodb').MongoClient;

MongoClient.connect('mongodb://react-lambda-client:react-lambda-client-pwd@ds147589.mlab.com:47589/react-lambda-client')
  .then((client) => {
    const db = client.db('react-lambda-client');
    return db.collection('to-do-items').find({}).toArray();
  })
  .then((docs) => {
    console.log(docs);
    process.exit();
  })
  .catch((err) => {
    console.log(err);
  });
